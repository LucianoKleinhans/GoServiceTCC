package com.lajotasoftware.goservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GoserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(GoserviceApplication.class, args);
	}

}
