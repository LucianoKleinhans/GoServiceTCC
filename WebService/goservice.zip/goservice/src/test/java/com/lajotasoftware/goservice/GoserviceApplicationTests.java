package com.lajotasoftware.goservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GoserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
